const appPasswords = { MONGO_DB_PASSWOPRD: "lJojxYspstyLYn2W", JWT_HASH: "secret" };

module.exports.appPasswords = appPasswords;
